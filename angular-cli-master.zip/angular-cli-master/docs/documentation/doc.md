<!-- Links in /docs/documentation should NOT have `.md` at the end, because they end up in our wiki at release. -->

# ng doc

## Overview
`ng doc [search term]` Opens the official Angular documentation for a given keyword on [angular.io](https://angular.io).

export {SchemaClass, SchemaClassFactory} from './schema-class-factory';
